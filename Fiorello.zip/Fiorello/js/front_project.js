$(document).ready(function () {

    // hide category
    $(".main_category_hide").click(function () {
        $(".hide_category_fade").toggle().removeClass("d-none", 3000);
    })

    $(".main_category_hide_filter").click(function () {
        $(".filters_child").toggle().removeClass("d-none");
    })

    // video 

$(".fa-play").click(function(e){
    $(".change_video").hide();
   $('.video_parts').trigger('play'); 
})

    let count = 1;
    $(".fa-caret-left").click(function () {
        $("#minus").val(`${count--}`);
        if (count <= 0) {
            $("#minus").val("Bu məhsul yoxdur");
        }
        count = 1;
    })
    $(".fa-caret-right").click(function () {
        $("#minus").val(`${count++}`);
    })

    // progresiv bar
    $('.skill-per').each(function () {
        var $this = $(this);
        var per = $this.attr('per');
        $this.css("width", per + '%');
        $({ animatedValue: 0 }).animate({ animatedValue: per }, {
            duration: 1000,
            step: function () {
                $this.attr('per', Math.floor(this.animatedValue) + '%');
            },
            complete: function () {
                $this.attr('per', Math.floor(this.animatedValue) + '%');
            }
        });
    });

    //   accordion menu
    $('.toggle').click(function (e) {
        event.preventDefault(e);
        let $this = $(this);
        $("li").siblings().find(".main").removeClass('main')
        $this.addClass("main");

        if ($('.inner').is(':visible')) {
            $(".inner");
            $(".sign").text('+');
        }
        if ($(this).next(".inner").is(':visible')) {
            $(this).next(".inner");
            $(this).children(".sign").text('+');
        } else {
            $(this).next(".inner");
            $(this).children(".sign").text('-');
        }

        if ($this.next().hasClass('show')) {
            $this.next().removeClass('show').slideUp(250);
        } else {
            $this.parent().parent().find('li .inner').removeClass('show');
            $this.parent().parent().find('li .inner').slideUp(250);
            $this.next().toggleClass('show');
            $this.next().slideToggle(250);
        }
    })

// image click scale
    $(".image_click").click(function(){
        $(".full_page").removeClass("d-none");
        $("header,.product_click_hide,footer").hide();
    })
    // header part 
    $(".closebtn").click(function () {
        $("#mySidenav").hide();
    })

    $("#span_drop").click(function () {
        $("#mySidenav").show();
        $("#mySidenav").css({ "width": "250px" })
    })

    //owl carusel   
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            800: {
                items: 4
            },
            1000: {
                items: 4
            }
        }
    })
});

// javascript scroll top parts
var mybutton = document.getElementById("myBtn");
window.onscroll = function () { scrollFunction() };
function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}
document.getElementById("myBtn").addEventListener("click", function () {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
})

